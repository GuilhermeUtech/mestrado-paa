#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "rgen_publico.h"

#define FRACASSO 0
#define SUCESSO 1

int obterBytesTipo(char * tipo, int * tamanho);